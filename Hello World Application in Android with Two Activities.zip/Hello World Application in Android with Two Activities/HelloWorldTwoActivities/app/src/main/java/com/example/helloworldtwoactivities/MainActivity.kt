package com.example.helloworldtwoactivities

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.buttonMain)
        val editText = findViewById<TextInputEditText>(R.id.editTextMain)
        val imageView = findViewById<ImageView>(R.id.imageMain)

        button.setOnClickListener {
            val name = editText.text.toString()
            Toast.makeText(this, "Hello, $name!", Toast.LENGTH_SHORT).show()
        }
    }
}
